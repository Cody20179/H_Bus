<!-- src/App.vue -->
<template>
  <router-view />
</template>

<script setup lang="ts">
/* 不要在這裡呼叫 createApp！*/
</script>
